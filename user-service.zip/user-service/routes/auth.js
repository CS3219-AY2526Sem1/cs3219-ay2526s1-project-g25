import express from 'express'
import { body } from 'express-validator'
import {
  register,
  verifyEmail, // for backend-only testing
  login,
  refreshToken,
  logout,
  requestPasswordReset,
  confirmPasswordReset
} from '../controllers/authController.js'

const router = express.Router()

// Register a new user
router.post(
  '/register',
  body('username').isLength({ min: 3 }),
  body('email').isEmail(),
  body('password').isString(),
  body('confirmPassword').isString(),
  register
)

// Handle Supabase verification redirect (when user clicks email link)
router.get('/verify', verifyEmail)

// Login user
router.post(
  '/login',
  body('identifier').isString(),
  body('password').isString(),
  login
)

// Refresh JWT tokens
router.post('/refresh', refreshToken)

// Logout user
router.post('/logout', logout)

// Request password reset email
router.post('/password-reset', body('email').isEmail(), requestPasswordReset)

// Confirm password reset
router.post(
  '/password-reset/confirm',
  body('token').isString(),
  body('newPassword').isString(),
  confirmPasswordReset
)

export default router